package com.day1.pack1;

public class ClassC {
	public void display() {
		System.out.println("TNS sessions");
	}

}
