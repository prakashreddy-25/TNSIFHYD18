package com.day1.pack1;

public class MyClassA {
	void display()
	{
		System.out.println("hello world");
	}

}
