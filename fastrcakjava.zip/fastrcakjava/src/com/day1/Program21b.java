package com.day1;

public class Program21b {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program21a p2a=new Program21a();
		p2a.display();

	}

}
