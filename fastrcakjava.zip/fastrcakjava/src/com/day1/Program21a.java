package com.day1;

public class Program21a {
	
	 private void display()
	{
		System.out.println("Hello World");
	}

}
