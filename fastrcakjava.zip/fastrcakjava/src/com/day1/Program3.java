package com.day1;

import java.util.Scanner;

public class Program3 {

	public static void main(String[] args) {
		
		int fact=1, i, n;
	
		System.out.println("enter the number:");
		Scanner scan =new Scanner(System.in);
		n=scan.nextInt();
		for(i=1;i<=n;i++) {
			if(i<1)
			{
				fact= 1;
			}
			else {
				fact=fact*i; 
			}
			
		}
		
		
		
		System.out.println("factorial ="+fact);	
		
		// TODO Auto-generated method stub

	}

}
