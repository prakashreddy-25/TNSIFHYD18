package com.day1;

import java.util.Scanner;

public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		System.out.println("enter the number:68");
		Scanner scan =new Scanner(System.in);
		n=scan.nextInt();
		
		if(n%2==0){
			System.out.println("it is even number");
		}
		else
		{
			System.out.println("it is an odd number");
		}

	}

}
