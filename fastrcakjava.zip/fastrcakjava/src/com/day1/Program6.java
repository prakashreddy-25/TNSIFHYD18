package com.day1;

import java.util.Scanner;

public class Program6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s;
		Scanner scan =new Scanner(System.in);
		s=scan.nextLine();
		String reversedStr ="";
		for (int i = s.length() - 1; i>= 0; i--) {
		reversedStr += s.charAt(i);
		}
		System.out.println("Reversed string:"  + reversedStr);
	}

}
