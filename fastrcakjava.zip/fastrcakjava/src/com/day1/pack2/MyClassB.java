package com.day1.pack2;

import com.day1.pack1.MyClassA;

public class MyClassB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClassA mca=new MyClassA();
		mca.display();
		

	}

}
