package com.day1.pack2;
import com.day1.pack1.*;

public class ClassB extends ClassA{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassB ca= new ClassB();
		ca.display();
		

	}

}
