package com.day1;

import java.util.Scanner; 

public class Program5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int f1=0,f2=1,f3 = 0, i, n;
		
		System.out.println("enter the number:");
		Scanner scan =new Scanner(System.in);
		n=scan.nextInt();
		System.out.println("fibonacci series of "+n);
		System.out.print(""+f1+","+f2+",");
		for(i=0;i<=n;++i) {
			f3=f1+f2;
			System.out.print(""+f3+",");
			f1=f2;
			f2=f3;
			
			}

	}
	

}
