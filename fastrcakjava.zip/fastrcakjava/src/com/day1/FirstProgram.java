//Demonstration of simple java program
package com.day1;

public class FirstProgram {
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}