package com.day1;

import java.util.Scanner;

public class Program4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int count=0, i, n;
	
		System.out.println("enter the number:");
		Scanner scan =new Scanner(System.in);
		n=scan.nextInt();
		for(i=1;i<n;i++) {
			if(n%i==0)
				count=count+1;
				
		}
		if(count>2) {
			System.out.println("it is not a  prime number");
		}
		else {
			System.out.println("it is  a prime number");
		}
	}

}
